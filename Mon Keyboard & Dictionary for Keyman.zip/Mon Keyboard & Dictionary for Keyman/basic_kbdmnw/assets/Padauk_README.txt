README
Padauk
========================

Padauk is a pan-Burma font designed to support all Myanmar script-based 
languages. It covers all of the Unicode Myanmar script blocks and works 
on all OpenType and Graphite based systems.

Features:
* Special support for: ksw, kht, kyu, shn, aio, phk, csh
* Variation Selector support for kht, aio, phk

Issues:
* Does not work in Word 2007


Padauk is released under the SIL Open Font License.
Padauk is a trademark of SIL International.
	
See the OFL and OFL-FAQ for details of the SIL Open Font License.
See the FONTLOG for information on this and previous releases.

For more information please visit the Padauk page on SIL International's 
website: http://software.sil.org/padauk.
